from torch import nn
import torch

class SeparateLoss(nn.Module):
    def __init__(self):
        super(SeparateLoss, self).__init__()

    def forward(self, predict, target):
        return torch.mean(0.25-(predict-0.5)**2)

class CRFLoss(nn.Module):
    """
    smooth_l1 + alpha * separate_loss
    """

    def __init__(self, alpha=0.5):
        super(CRFLoss, self).__init__()
        self.alpha = alpha
        self.smooth_l1 = nn.SmoothL1Loss()

    def forward(self, predict, target):
        return self.smooth_l1(predict, target)
