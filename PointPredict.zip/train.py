if __name__=='__main__':
    from dataset.dataLoader import create_dataloaders
    from model.ResAttentionNet import make_model

    import torch
    import json
    from utils.utils import CRFLoss

    from torch.utils.tensorboard import SummaryWriter
    from torch.optim.lr_scheduler import StepLR

    import time

    log_dir = './runs/{}'.format(time.strftime('%Y.%m.%d-%H-%M',
                                time.localtime(time.time())))

    device = torch.device('cuda:0' if torch.cuda.is_available()
                        else 'cpu')
    writer = SummaryWriter(log_dir)


    config = {
        # 路径参数
        'path': {
            'final_model_path': '{}/final.pt'.format(writer.log_dir),
            'best_model_path': '{}/best.pt'.format(writer.log_dir),
            'data_path': 'data/nuscenes-front/',
            'config_path': '{}/config.json'.format(writer.log_dir),
        },

        #  构建模型参数
        'make_model_parameter': {
            'd_input': 16,
            'd_model': 64,
            'in_width': 800,
            'out_width': 400,
            'N': 2
        },

        # 学习率设置
        'learning_rate': {
            'base_learning_rate': 0.000004,
            'step_size': 10,
            'gamma': 0.6
        },

        # 训练参数
        'train_epoch': 100,
        'demo_interval': 10,
        'loss_alpha': 0.12,

        # 断点续训练功能
        'load_pretrained_model': False,
        'pretrained_model_path': './runs/{}/final.pt'\
                                .format('Nov24_00-05-26_yishiyu-lab-ubuntu-66c25a75'),

        'train_marks': {
            # 'name': 'mark',
        },

        'best_model': {
            'epoch': 0,
            'loss': 1000
        }
    }


def main():
    model = make_model().to(device)

    # 加载已训练模型并添加标注
    if config['load_pretrained_model']:
        model.load_state_dict(
            torch.load(config['pretrained_model_path'],
                       map_location=device)
        )
        writer.add_text('pretrained_model_path',
                        config['pretrained_model_path'])
    else:
        writer.add_text('pretrained_model_path',
                        'NONE')

    # 添加训练标注
    for name, mark in config['train_marks']:
        writer.add_text('train_mark_{}'.format(name), mark)

    train_dataset, train_data_loader, val_data_loader = create_dataloaders(
        batch_size=8,
        num_workers=4
    )

    criterion = CRFLoss(alpha=config['loss_alpha'])
    val_loss = torch.nn.MSELoss()
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=config['learning_rate']['base_learning_rate']
    )
    lr_scheduler = StepLR(
        optimizer,
        step_size=config['learning_rate']['step_size'],
        gamma=config['learning_rate']['gamma']
    )

    epoch = config['train_epoch']
    for e in range(epoch):

        model.train()   
        train(e, model, train_data_loader, criterion, optimizer)

        model.eval()
        evaluate(e, model, val_data_loader, criterion, optimizer)

        lr_scheduler.step()
        # writer.flush()

        torch.save(model.state_dict(), config['path']['final_model_path'])

    writer.close()

    with open(config['path']['config_path'], 'w') as file:
        json.dump(config, file)


def train(epoch, model, data_loader, criterion, optimizer):
    total_loss = 0
    total_batch = 0
    for i, (RD, RA, RE, Skeleton) in enumerate(data_loader):
        RD = RD.to(device)
        RA = RA.to(device)
        RE = RE.to(device)
        Skeleton = Skeleton.to(device)

        predict = model(RD, RA, RE)

        loss = criterion(predict, Skeleton)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        total_batch += 1

        if i % 10 == 0:
            print('epoch:{:0>3d} || batch {:0>3d} with loss:{:>10f}'
                  .format(epoch, i,  loss))

    del RD
    del RA
    del RE
    del Skeleton
    del predict
    del loss
    writer.add_scalar('Loss/train', total_loss / total_batch, epoch+1)
    

def evaluate(epoch, model, data_loader, criterion, optimizer):
    # evaluate loss
    total_loss = 0
    total_batch = 0
    for i, (RD, RA, RE, Skeleton) in enumerate(data_loader):
        RD = RD.to(device)
        RA = RA.to(device)
        RE = RE.to(device)
        Skeleton = Skeleton.to(device)

        predict = model(RD, RA, RE)

        loss = criterion(predict, Skeleton)

        total_loss += loss.item()
        total_batch += 1

    # 保存最佳模型
    average_loss = total_loss / total_batch
    if average_loss < config['best_model']['loss']:
        config['best_model']['loss'] = average_loss
        config['best_model']['epoch'] = epoch
        torch.save(model.state_dict(), config['path']['best_model_path'])

    writer.add_scalar('Loss/evaluate', average_loss, epoch)

    # 学习率曲线
    writer.add_scalar('Learning Rate',
                      optimizer.param_groups[0]['lr'],
                      epoch)

    # 效果图
    # if epoch % config['demo_interval'] == 0:
    #     demo_figs = demo(model, device, data_loader, writer,
    #                      epoch, config['path']['data_path'], wave_width=400)
    #     # writer.add_figure('demo/evaluate', demo_figs, epoch, True)
    # pass


if __name__ == '__main__':
    main()
