from pathlib import Path
from torch.utils.data import Dataset, DataLoader
import json
import numpy as np
import torch
from torch.utils.data import random_split, SubsetRandomSampler


class RadDatesetCacheDataset(Dataset):
    def __init__(self,
                 data_path='data',
                 version='1'):

        super(RadDatesetCacheDataset, self).__init__()

        self.data_path = data_path
        
        with open('{}/cached/{}.json'.format(data_path, version), 'r') as file:
            self.samples = json.load(file)

    def __getitem__(self, i):
        RD = np.load(self.samples[i]['rd_file'],allow_pickle=True)
        RA = np.load(self.samples[i]['ra_file'],allow_pickle=True)
        RE = np.load(self.samples[i]['re_file'],allow_pickle=True)
        Skeleton = np.load(self.samples[i]['skeleton_file'],allow_pickle=True)
        return RD,RA,RE,Skeleton

    def __len__(self):
        return len(self.samples)

    @staticmethod
    def collate_fn(batch):
        RD, RA, RE, Skeleton  = zip(*batch)
        RD = np.stack(RD).astype(np.float32)
        RA = np.stack(RA).astype(np.float32)
        RE = np.stack(RE).astype(np.float32)
        Skeleton = np.stack(Skeleton).astype(np.float32)
        return torch.from_numpy(RD),torch.from_numpy(RA),torch.from_numpy(RE),torch.from_numpy(Skeleton)
        
def create_dataloader(
    data_path='data',
    version='1',
    batch_size=8,
    num_workers=1,
):

    dataset = RadDatesetCacheDataset(data_path=data_path, version=version)

    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        collate_fn=RadDatesetCacheDataset.collate_fn,
    )
    return dataset, dataloader


def create_dataloaders(
    data_path='data',
    version='1',
    train_ratio=0.8,
    batch_size=32,
    random_seed=125,
    num_workers=4
):
    """根据指定版本数据集`划分出训练集和验证集`,并分别生成 dataloader
    """
    assert(train_ratio > 0 and train_ratio < 1)

    dataset = RadDatesetCacheDataset(data_path=data_path,
                                    version=version)
    
    sample_count = len(dataset)
    train_index, val_index = \
        random_split(range(sample_count),
                     [round(train_ratio * sample_count),
                      round((1-train_ratio)*sample_count)],
                     generator=torch.Generator().manual_seed(random_seed))
    train_index = [sample for sample in train_index]
    val_index = [sample for sample in val_index]
    np.random.shuffle(train_index)
    np.random.shuffle(val_index)

    train_sampler = SubsetRandomSampler(train_index)
    val_sampler = SubsetRandomSampler(val_index)

    train_loader = DataLoader(dataset, batch_size,
                              num_workers=num_workers,
                              sampler=train_sampler,
                              collate_fn=RadDatesetCacheDataset.collate_fn)
    val_loader = DataLoader(dataset, batch_size,
                            num_workers=num_workers,
                            sampler=val_sampler,
                            collate_fn=RadDatesetCacheDataset.collate_fn)

    return dataset, train_loader, val_loader

if __name__ == "__main__" : 
    dataset, train_loader, val_loader = create_dataloaders()
    for i, (RD, RA, RE, Skeleton) in enumerate(train_loader):
        pass 
    for i, (RD, RA, RE, Skeleton) in enumerate(val_loader):
        pass 