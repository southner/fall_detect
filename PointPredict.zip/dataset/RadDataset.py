from pathlib import Path
import numpy as np
import scipy.io as scio
from os import listdir
import os.path as opt

from torch.utils.data import Dataset, DataLoader
from torch.utils.data import random_split, SubsetRandomSampler
config = {
    'img_size':{
        'range':144,
        'doppler':80,
        'angle':64
    }
}

class RadDateset(Dataset):
    #将文件处理为sample，交给cache函数存下来
    def __init__(self,
                data_path=r"d:\workspace\experiments\data_save",
                data_save_path = r"",
                shuffle=False):
        super(RadDateset).__init__()
        self.data_path = data_path
        self.data_save_path = data_save_path

        #参数
        self.window_step = 5
        self.window_size = 10

        #处理数据
        self.samples = []
        self.file_sample_index = []
        dirs = listdir(self.data_path)
        sample_index = 0 
        for dir_name in dirs:
            dir = opt.join(self.data_path,dir_name)
            radar_data = scio.loadmat(opt.join(dir,'three_tensor.mat'))
            skeleton_data = np.load(opt.join(dir,'skeleton_res.npy'))
            frame_size = len(radar_data['doppler_res'])

            # 将图片长宽颠倒，变为(range,another)
            radar_data_doppler = np.transpose(radar_data['doppler_res'],(0,-1,-2))
            radar_data_azimuth = np.transpose(radar_data['azimuth_res'],(0,-1,-2))
            radar_data_elevation = np.transpose(radar_data['elevation_res'],(0,-1,-2))

            self.file_sample_index.append(sample_index)
            for sample_start_index in range(0,frame_size-self.window_step,self.window_step):
                temp = {}
                temp['RD'] = radar_data_doppler[sample_start_index:sample_start_index+self.window_size,:config['img_size']['range'],:config['img_size']['doppler']]
                temp['RA'] = radar_data_azimuth[sample_start_index:sample_start_index+self.window_size,:config['img_size']['range'],:config['img_size']['angle']]
                temp['RE'] = radar_data_elevation[sample_start_index:sample_start_index+self.window_size,:config['img_size']['range'],:config['img_size']['angle']]
                temp['Skeleton'] = skeleton_data[sample_start_index:sample_start_index+self.window_size,:,:,:]/100
                sample = {}
                sample['RD'] = np.concatenate((temp['RD'][0:5],temp['RD'][6:]),axis=0)
                sample['RA'] = np.concatenate((temp['RA'][0:5],temp['RA'][6:]),axis=0)
                sample['RE'] = np.concatenate((temp['RE'][0:5],temp['RE'][6:]),axis=0)
                # sample['Skeleton'] = np.concatenate((temp['Skeleton'][5],(temp['Skeleton'][0]-temp['Skeleton'][9])*2),-1)
                sample['Skeleton'] = temp['Skeleton'][5,:,:,2]
                self.samples.append(sample)
                sample_index+=1
                pass
            pass

        self.file_sample_length = self.file_sample_index[1]  #一个文件被处理成多少个sample

        pass
    def __getitem__(self, index):
        return self.samples[index]

    def __len__(self):
        return len(self.samples)
        
        

if __name__ =="__main__":
    dataset = RadDateset()

